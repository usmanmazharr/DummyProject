
import TunnelKitWireGuardAppExtension

class PacketTunnelProvider: WireGuardTunnelProvider {
}
