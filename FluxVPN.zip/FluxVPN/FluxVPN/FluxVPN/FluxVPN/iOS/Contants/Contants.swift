 
import Foundation
import UIKit

struct K {
    struct ProductionServer {
        static let baseURL = "http://itechnodev.com/api"
    }

    struct APIParameterKey {
        static let password = "password"
        static let email = "email"
    }
}

enum HTTPHeaderField: String {
    case authentication = "Authorization"
    case contentType = "Content-Type"
    case acceptType = "Accept"
    case acceptEncoding = "Accept-Encoding"
}

enum ContentType: String {
    case json = "application/json"
}

let BASE_URL = "http://rd2s.cloud/"

let LOGIN_USER = "api_app.php"

let RESET_USER = "api_reset.php"

let HOME_PAGE = "api_server3.php"

let GET_SEVER_INFO = "api_client3.php"

let LOGOUT_CLIENT = "api_client_logout.php"

// PAYPAL
let PayPal_Environment_Production = "AXwwQuAvoGfONavK0cN3JA50BThsYnL4a0CTtmzzkKFWx6SFxMAy6TsRE-Aq0s-7GkWYtpRfhvW90fEm"

let PayPal_Environment_Sandbox = "AXwwQuAvoGfONavK0cN3JA50BThsYnL4a0CTtmzzkKFWx6SFxMAy6TsRE-Aq0s-7GkWYtpRfhvW90fEm"

// *****************************************************

let appDelegate = UIApplication.shared.delegate as! AppDelegate
