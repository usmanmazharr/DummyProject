
import UIKit
import Foundation
//import NetworkExtension
//import SwiftyBeaver
//import IQKeyboardManagerSwift

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate {
 

    var window: UIWindow?
    var dicCurrentUserData = FVUserLoginData()
 //   private let log = SwiftyBeaver.self

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window?.overrideUserInterfaceStyle = .dark

        AppUtilites.Singleton.sharedInstance.isConnected = true
//        IQKeyboardManager.shared.enable = true

        let targetLang = UserDefaults.standard.value(forKey: "AppleLanguages") as? String
        
        LanguageManager.shared.setLanguage(targetLang != nil ? targetLang!: "en")
      
        if let isUserLogin = UserDefaults.standard.value(forKey: "isUserLogin") as? Bool
        {
            if isUserLogin == true
            {
                self.dicCurrentUserData = self.getCurrentUserData()
                self.setUpHome()
            }
            else
            {
                self.setUpLogin()
            }
        }
        else
        {
            self.setUpLogin()
        }
        
//        let logDestination = ConsoleDestination()
//        logDestination.minLevel = .debug
//        logDestination.format = "$DHH:mm:ss$d $L $N.$F:$l - $M"
//        log.addDestination(logDestination)

        // Override point for customization after application launch.
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    func setUpHome()
    {
        let mainStoryboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let home: DashboardViewController = mainStoryboard.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
        let homeNavigation = UINavigationController(rootViewController: home)
        homeNavigation.navigationBar.isHidden = true
        self.window?.rootViewController = homeNavigation
        self.window?.makeKeyAndVisible()
    }
    
    
    
    func setUpLogin()
    {
        let mainStoryboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let home: LogInViewController = mainStoryboard.instantiateViewController(withIdentifier: "LogInViewController") as! LogInViewController
        let homeNavigation = UINavigationController(rootViewController: home)
        homeNavigation.navigationBar.isHidden = true
        self.window?.rootViewController = homeNavigation
        self.window?.makeKeyAndVisible()
    }
 
    func saveCurrentUserData(dic: FVUserLoginData)
    {
        let data = NSKeyedArchiver.archivedData(withRootObject: dic)
        UserDefaults.standard.setValue(data, forKey: "currentUserDataFV")
        UserDefaults.standard.synchronize()
    }
    
    func getCurrentUserData() -> FVUserLoginData
    {
        if let data = UserDefaults.standard.object(forKey: "currentUserDataFV"){
            
            let arrayObjc = NSKeyedUnarchiver.unarchiveObject(with: data as! Data)
            return arrayObjc as! FVUserLoginData
        }
        return FVUserLoginData()
    }

    
}


