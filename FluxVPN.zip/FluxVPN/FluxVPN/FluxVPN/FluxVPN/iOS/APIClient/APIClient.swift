import Foundation
import Alamofire
import SVProgressHUD
import UIKit

class APIClient: NSObject {

    typealias completion = ( _ result: Dictionary<String, Any>, _ error: Error?) -> Void

    class var sharedInstance: APIClient {

        struct Static {
            static let instance: APIClient = APIClient()
        }
        return Static.instance
    }

    var responseData: NSMutableData!

    func pushNetworkErrorVC() {
        AppUtilites.showAlert(title: "No Network Found!", message: "No Internet connection was found. Check your connection or try again.", cancelButtonTitle: "Try again")
    }

    func MakeAPICallWithAuthHeaderGet(_ url: String, parameters: [String: Any], completionHandler: @escaping (NSDictionary?, Error?, Int?) -> Void) {

        print("url = \(BASE_URL + url)")

        if NetConnection.isConnectedToNetwork() == true {

            let userToken = UserDefaults.standard.value(forKey: "userToken") as? String

            let headers: HTTPHeaders = ["Authorization": "Bearer \(userToken ?? "")"]

            AF.request(BASE_URL + url, method: .get, parameters: parameters, encoding: URLEncoding(destination: .methodDependent), headers: headers) .responseJSON { (response) in

                switch response.result {

                case .success:
                    if response.value != nil {
                        if let responseDict = ((response.value as AnyObject) as? NSDictionary) {
                            completionHandler(responseDict, nil, response.response?.statusCode)
                        }
                    }

                case .failure:
                    print(response.error!)
                    print("Http Status Code: \(String(describing: response.response?.statusCode))")
                    completionHandler(nil, response.error, response.response?.statusCode )
                }
            }.cURLDescription { description in
                print("====== CURL =====> \(description)")
            }
        } else {
            print("No Network Found!")
            pushNetworkErrorVC()
//            SVProgressHUD.dismiss()
            Spinner.stop()
        }
    }

    func MakeAPICallWithAuthHeaderManualGet(_ url: String, headers: HTTPHeaders, parameters: [String: Any], completionHandler: @escaping (NSDictionary?, Error?, Int?) -> Void) {

        print("url = \(BASE_URL + url)")

        if NetConnection.isConnectedToNetwork() == true {

            let userToken = UserDefaults.standard.value(forKey: "userToken") as? String

          //  let headers: HTTPHeaders = ["Authorization":"Bearer \(userToken ?? "")"]

            AF.request(BASE_URL + url, method: .get, parameters: parameters, encoding: URLEncoding(destination: .methodDependent), headers: headers) .responseJSON { (response) in

                switch response.result {

                case .success:
                    if response.value != nil {
                        if let responseDict = ((response.value as AnyObject) as? NSDictionary) {
                            completionHandler(responseDict, nil, response.response?.statusCode)
                        }
                    }

                case .failure:
                    print(response.error!)
                    print("Http Status Code: \(String(describing: response.response?.statusCode))")
                    completionHandler(nil, response.error, response.response?.statusCode )
                }
            }.cURLDescription { description in
                print("====== CURL =====> \(description)")
            }
        } else {
            print("No Network Found!")
            pushNetworkErrorVC()
//            SVProgressHUD.dismiss()
            Spinner.stop()
        }
    }
    
    func MakeAPICallWithAuthHeaderManualPost(_ url: String, headers: HTTPHeaders, parameters: [String: Any], completionHandler: @escaping (NSDictionary?, Error?, Int?) -> Void) {

        print("url = \(BASE_URL + url)")

        if NetConnection.isConnectedToNetwork() == true {

            let userToken = UserDefaults.standard.value(forKey: "userToken") as? String

          //  let headers: HTTPHeaders = ["Authorization":"Bearer \(userToken ?? "")"]

            AF.request(BASE_URL + url, method: .post, parameters: parameters, encoding: URLEncoding(destination: .methodDependent), headers: headers) .responseJSON { (response) in

                switch response.result {

                case .success:
                    if response.value != nil {
                        if let responseDict = ((response.value as AnyObject) as? NSDictionary) {
                            completionHandler(responseDict, nil, response.response?.statusCode)
                        }
                    }

                case .failure:
                    print(response.error!)
                    print("Http Status Code: \(String(describing: response.response?.statusCode))")
                    completionHandler(nil, response.error, response.response?.statusCode )
                }
            }.cURLDescription { description in
                print("====== CURL =====> \(description)")
            }
        } else {
            print("No Network Found!")
            pushNetworkErrorVC()
//            SVProgressHUD.dismiss()
            Spinner.stop()
        }
    }

    func MakeAPICallWithOutAuthHeaderGet(_ url: String, parameters: [String: Any], completionHandler: @escaping (NSDictionary?, Error?, Int?) -> Void) {

        print("url = \(BASE_URL + url)")

        if NetConnection.isConnectedToNetwork() == true {

            AF.request(BASE_URL + url, method: .get, parameters: parameters, encoding: URLEncoding(destination: .methodDependent), headers: nil) .responseJSON { (response) in

                switch response.result {

                case .success:
                    if response.value != nil {
                        if let responseDict = ((response.value as AnyObject) as? NSDictionary) {
                            completionHandler(responseDict, nil, response.response?.statusCode)
                        }
                    }

                case .failure:
                    print(response.error!)
                    print("Http Status Code: \(String(describing: response.response?.statusCode))")
                    completionHandler(nil, response.error, response.response?.statusCode )
                }
            }.cURLDescription { description in
                print("====== CURL =====> \(description)")
            }
        } else {
            print("No Network Found!")
            pushNetworkErrorVC()
//            SVProgressHUD.dismiss()
            Spinner.stop()
        }
    }

    func showIndicator() {
        DispatchQueue.main.async {
//            SVProgressHUD.show()
            Spinner.start()
        }

    }

    func hideIndicator() {
        DispatchQueue.main.async {
//            SVProgressHUD.dismiss()
            Spinner.stop()
        }

    }

    func showSuccessIndicator(message: String) {
        SVProgressHUD.showSuccess(withStatus: message)
    }
}

open class Spinner {
    
    private static var blockingView: UIView?
    private static let shared = Spinner()
    public static func start() {
        _ = Spinner.shared
        if blockingView == nil, let window = UIWindow.key {
            let frame = UIScreen.main.bounds
            
            blockingView = UIView(frame: frame)
            blockingView?.backgroundColor = .black.withAlphaComponent(0.3)
            
            window.addSubview(blockingView!)
            SVProgressHUD.show()
        }
    }
    public static func stop() {
        if blockingView != nil {
            SVProgressHUD.dismiss()
            blockingView?.removeFromSuperview()
            blockingView = nil
        }
    }
}

extension UIWindow {
    static var key: UIWindow? {
        if #available(iOS 13, *) {
            return UIApplication.shared.windows.first { $0.isKeyWindow }
        } else {
            return UIApplication.shared.keyWindow
        }
    }
}
