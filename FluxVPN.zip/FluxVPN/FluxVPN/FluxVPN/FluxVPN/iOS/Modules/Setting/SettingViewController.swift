
import UIKit
import Alamofire
import TunnelKitManager

class SettingViewController: UIViewController {

    @IBOutlet weak var lblSelectLang: UILabel!
    @IBOutlet weak var lbl_delete: UILabel!
    @IBOutlet weak var lbl_delete_des: UILabel!
    
    @IBOutlet weak var imgAuto: UIImageView!
    
    var isVpnConnect = false
    var vpnInfo : VPNInfoModel!
    
    private let vpn = NetworkExtensionVPN()
    var vpnStatus: VPNStatus = .disconnected
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imgAuto.image = UIImage(named: "ic_Uncheck")
        
        lbl_delete.text = "delete_account".localized()
        lbl_delete_des.text = "delete_des".localized()

    }
 
    @IBAction func clickedBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func clickedng(_ sender: Any) {
        
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "LanguageViewController") else { return  }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func clickedAuto(_ sender: Any) {
        
        if isVpnConnect
        {
            isVpnConnect = false
            imgAuto.image = UIImage(named: "ic_check")
        }
        else
        {
            isVpnConnect = true
            imgAuto.image = UIImage(named: "ic_Uncheck")
        }
    }
    
    @IBAction func clickeLogout(_ sender: Any) {
        
        self.logOutVPN {
            self.callLogoutAPI()
        }
     
    }
    
    
    @IBAction func clickDelete(_ sender: Any) {
        
        showDeleteAlert(title: "delete_account".localized(), desc: "delete_des".localized()) {
            self.deleteAccountApi()
        }
    }
    
    func callLogoutAPI()
    {
        APIClient.sharedInstance.showIndicator()
        
        let param = ["":""]
        
        let headers: HTTPHeaders = ["TOKEN":"mIjuu3bYa3kK1STn5uf8ylbLi0veLTb5","ID": AppUtilites().getCurrentUserData().userId ?? "","IP":"ipAddress"]
        
        print(param)
        
        APIClient.sharedInstance.MakeAPICallWithAuthHeaderManualGet(LOGOUT_CLIENT,headers: headers, parameters: param) {
            response, error, statusCode in
            
            print("STATUS CODE \(String(describing: statusCode))")
            print("RESPONSE \(String(describing: response))")
            
            if error == nil
            {
                APIClient.sharedInstance.hideIndicator()
                
                let message = response?.value(forKey: "message") as? String

                if statusCode == 200
                {
                    if message == "Done"
                    {
                        if self.vpnStatus == .connected {
                            Task {
                                await self.vpn.disconnect()
                                    UserDefaults.standard.setValue(nil, forKey: "currentConnectedName")
                                    UserDefaults.standard.setValue(nil, forKey: "currentConnectedID")
                                    UserDefaults.standard.set(nil, forKey: "vpnInfo")

                                    UserDefaults.standard.set(false, forKey: "isUserLogin")
                                    UserDefaults.standard.synchronize()
                                    let mainStoryboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                                    let home: LogInViewController = mainStoryboard.instantiateViewController(withIdentifier: "LogInViewController") as! LogInViewController
                                    let homeNavigation = UINavigationController(rootViewController: home)
                                    let delegate = UIApplication.shared.delegate as! AppDelegate
                                    homeNavigation.navigationBar.isHidden = true
                                    delegate.window?.rootViewController = homeNavigation
                                    delegate.window?.makeKeyAndVisible()
//                                }
                            }
                        } else {
                            UserDefaults.standard.setValue(nil, forKey: "currentConnectedName")
                            UserDefaults.standard.setValue(nil, forKey: "currentConnectedID")
                            UserDefaults.standard.set(nil, forKey: "vpnInfo")
                            
                            UserDefaults.standard.set(false, forKey: "isUserLogin")
                            UserDefaults.standard.synchronize()
                            let mainStoryboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                            let home: LogInViewController = mainStoryboard.instantiateViewController(withIdentifier: "LogInViewController") as! LogInViewController
                            let homeNavigation = UINavigationController(rootViewController: home)
                            let delegate = UIApplication.shared.delegate as! AppDelegate
                            homeNavigation.navigationBar.isHidden = true
                            delegate.window?.rootViewController = homeNavigation
                            delegate.window?.makeKeyAndVisible()
                        }
                    }
                    else
                    {
                        self.view.makeToast(message)
                        let window = UIApplication.shared.windows
                        window.last?.makeToast(message)
                    }
                }
                else
                {
                    self.view.makeToast(message)
                    let window = UIApplication.shared.windows
                    window.last?.makeToast(message)
                }
                
            }
            else
            {
                APIClient.sharedInstance.hideIndicator()
               
            }
        }
    }
    
    func logOutVPN( completion: @escaping (() -> Void)) {
        let param = ["":""]
        let clientAddress: String = self.vpnInfo?.Clientinfo?.Address ?? ""
        let headers: HTTPHeaders = [
            "Token":"mIjuu3bYa3kK1STn5uf8ylbLi0veLTb5",
            "ID": AppUtilites().getCurrentUserData().userId ?? "",
            "IP": clientAddress
           
        ]
        APIClient.sharedInstance.showIndicator()
        APIClient.sharedInstance.MakeAPICallWithAuthHeaderManualGet("api_client_logout.php",headers: headers, parameters: param) {
            response, error, statusCode in
            APIClient.sharedInstance.hideIndicator()
            if error == nil
            {
                if statusCode == 200
                {
                    completion()
                }
            }
            else
            {
                print("getServerInfo Error \(String(describing: response))")
           
            }
        }
    }
    
    func deleteAccountApi() {
        let param = ["":""]
        let headers: HTTPHeaders = [
            "Token":"mIjuu3bYa3kK1STn5uf8ylbLi0veLTb5",
            "ID": AppUtilites().getCurrentUserData().userId ?? ""
        ]
        APIClient.sharedInstance.showIndicator()
        APIClient.sharedInstance.MakeAPICallWithAuthHeaderManualGet("api_delete_account.php",headers: headers, parameters: param) {
            response, error, statusCode in
            APIClient.sharedInstance.hideIndicator()
            if error == nil
            {
                if statusCode == 200
                {
                    UserDefaults.standard.setValue(nil, forKey: "currentConnectedName")
                    UserDefaults.standard.setValue(nil, forKey: "currentConnectedID")
                    UserDefaults.standard.set(nil, forKey: "vpnInfo")

                    UserDefaults.standard.set(false, forKey: "isUserLogin")
                    UserDefaults.standard.synchronize()
                    let mainStoryboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let home: LogInViewController = mainStoryboard.instantiateViewController(withIdentifier: "LogInViewController") as! LogInViewController
                    let homeNavigation = UINavigationController(rootViewController: home)
                    let delegate = UIApplication.shared.delegate as! AppDelegate
                    homeNavigation.navigationBar.isHidden = true
                    delegate.window?.rootViewController = homeNavigation
                    delegate.window?.makeKeyAndVisible()
                }
            }
            else
            {
                print("getServerInfo Error \(String(describing: response))")
           
            }
        }
    }
    
    func showDeleteAlert(title: String, desc: String, completion: (() -> Void)? = nil ) {
        let dialogMessage = UIAlertController(title:title, message: desc, preferredStyle: .alert)
        //var dialogMessage = UIAlertController(title: "VPN Expired", message: "Your VPN subscription has expired. Please renew to continue using the", preferredStyle: .alert)
        let ok = UIAlertAction(title: "Yes".localized(), style: .default, handler: { (action) -> Void in
            print("--OK--")
            completion?()
         })
        //Add OK button to a dialog message
        dialogMessage.addAction(ok)
     
        dialogMessage.addAction(UIAlertAction(title: "No".localized(), style: UIAlertAction.Style.cancel, handler: { (action) -> Void in
            print("--Cancel--")
             
         }))
        
        // Present Alert to
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
}
