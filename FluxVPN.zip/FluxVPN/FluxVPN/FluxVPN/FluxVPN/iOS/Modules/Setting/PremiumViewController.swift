
import UIKit
import StoreKit
import Alamofire

class PremiumViewController: BaseViewController, SKPaymentTransactionObserver {

    @IBOutlet weak var view_one_month: UIView!
    @IBOutlet weak var view_three_month: UIView!
    @IBOutlet weak var view_six_month: UIView!
    @IBOutlet weak var view_twelve_month: UIView!

    var unlockTestInAppPurchase1ProductId: String!
    private var paymentIntentClientSecret: String?

    private var products = [SKProduct]()
    private var productsBeingPurchased: SKProduct?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        unlockTestInAppPurchase1ProductId = "one.month.plan"
    }

    
    @IBAction func clickedBack(_ sender: Any) {
      self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func buynowBtnClicked(_ sender: UIButton) {
        
        if unlockTestInAppPurchase1ProductId != nil {
            DispatchQueue.main.async{
                self.fetchProducts()
            }
        } else {
            let window = UIApplication.shared.windows
            window.last?.makeToast("Please Select a Subscription Plan")
        }
    }
    
    @IBAction func planClicked(_ sender: UIButton) {

        view_one_month.backgroundColor = UIColor(red: 31/255, green: 31/255, blue: 37/255, alpha: 1.0)
        view_three_month.backgroundColor = UIColor(red: 31/255, green: 31/255, blue: 37/255, alpha: 1.0)
        view_six_month.backgroundColor = UIColor(red: 31/255, green: 31/255, blue: 37/255, alpha: 1.0)
        view_twelve_month.backgroundColor = UIColor(red: 31/255, green: 31/255, blue: 37/255, alpha: 1.0)

        if sender.tag == 0 {
            view_one_month.backgroundColor = UIColor(red: 14/255, green: 84/255, blue: 179/255, alpha: 1.0)
            unlockTestInAppPurchase1ProductId = "one.month.plan"

        } else if sender.tag == 1 {
            view_three_month.backgroundColor = UIColor(red: 14/255, green: 84/255, blue: 179/255, alpha: 1.0)
            unlockTestInAppPurchase1ProductId = "three.months.plan"

        } else if sender.tag == 2 {
            view_six_month.backgroundColor = UIColor(red: 14/255, green: 84/255, blue: 179/255, alpha: 1.0)
            unlockTestInAppPurchase1ProductId = "six.months.plan"

        } else {
            view_twelve_month.backgroundColor = UIColor(red: 14/255, green: 84/255, blue: 179/255, alpha: 1.0)
            unlockTestInAppPurchase1ProductId = "twelve.months.plan"

        }
    }
    
    @IBAction func urlBtnClicked(_ sender: UIButton) {
        
        if sender.tag == 4 {
            let myString = "https://www.rd2s.cloud/EULA.html"
    
            guard let url = URL(string: myString) else {
              return //be safe
            }
    
            if UIApplication.shared.canOpenURL(url) {
                if #available(iOS 13.0, *) {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        } else {
            
            let policyString = "https://www.rd2s.cloud/privacy-policy.html"
    
            guard let url = URL(string: policyString) else {
              return //be safe
            }
    
            if UIApplication.shared.canOpenURL(url) {
                if #available(iOS 13.0, *) {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        }
    }
    
    // MARK: After Payment Success API
    func afterSuccessApi(idUser: String) {
        let param = ["id_user":idUser]
        let headers: HTTPHeaders = ["Content-Type": "application/x-www-form-urlencoded", "ID": AppUtilites().getCurrentUserData().userId ?? ""
        ]
  //  https://www.rd2s.cloud/api_applepayment.php
        APIClient.sharedInstance.showIndicator()
        APIClient.sharedInstance.MakeAPICallWithAuthHeaderManualPost("api_applepayment.php",headers: headers, parameters: param) {
            response, error, statusCode in
            APIClient.sharedInstance.hideIndicator()
            if error == nil
            {
                if statusCode == 200
                {
                    
                }
            }
            else
            {
                print("getServerInfo Error \(String(describing: response))")
           
            }
        }
    }
}

extension PremiumViewController: SKProductsRequestDelegate {

    private func fetchProducts() {
        let productIdentifiers: Set<String> = [unlockTestInAppPurchase1ProductId]
        let productsRequest = SKProductsRequest(productIdentifiers: productIdentifiers)
        productsRequest.delegate = self
        productsRequest.start()
    }

    func productsRequest(_ request: SKProductsRequest, didReceive response: SKProductsResponse) {
        products = response.products

//        for product in products {
//            print("Product: \(product.localizedTitle), Price: \(product.price)")
//        }

        guard let product = products.first else {
            return
        }
        purchase(product: product)
    }

    func request(_ request: SKRequest, didFailWithError error: Error) {
        guard request is SKProductsRequest else {
            return
        }

        print("Product request fetch failed")
    }


    func purchase(product: SKProduct) {

        guard SKPaymentQueue.canMakePayments() else {
            return
        }
        productsBeingPurchased = product
        let payment = SKPayment(product: product)
        SKPaymentQueue.default().add(self)
        SKPaymentQueue.default().add(payment)
//        print(productsBeingPurchased)
    }

    func paymentQueue(_ queue: SKPaymentQueue, updatedTransactions transactions: [SKPaymentTransaction]) {

        transactions.forEach({ transaction in

            switch transaction.transactionState {
            case .purchased:
                // Process successful purchase
//                handlePurchase(transaction.payment.productIdentifier)
                print(transaction.transactionIdentifier as Any)
                var receiptBase: String = ""
                  if let receiptURL = Bundle.main.appStoreReceiptURL {
                  do {
                      let receipt = try Data(contentsOf: receiptURL)
                      let base64encodedReceipt = receipt.base64EncodedString()
                      receiptBase = base64encodedReceipt
                      print(receiptBase)
                  } catch {
                      receiptBase = ""
                  }
                  }
//                self.afterSuccessApi(idUser: <#String#>, payment_status: <#String#>, signature: <#String#>, mesi: <#String#>)
                SKPaymentQueue.default().finishTransaction(transaction)
            case .failed:
                // Handle failed purchase
                print("Product fetch failed")
                SKPaymentQueue.default().finishTransaction(transaction)
                SKPaymentQueue.default().remove(self)
            case .restored:
                // Handle restored purchase
                restorePurchase()
                SKPaymentQueue.default().finishTransaction(transaction)
            case .purchasing:
                // Handle ongoing purchase
//                fetchPaymentIntent()
                print("Product openedddd")

                break
            case .deferred:
                print("Product deferred")

            @unknown default:
                break
            }
        })
    }
    
    // RESTORE PURCHASE
    private  func restorePurchase() {
       SKPaymentQueue.default().add(self)
       SKPaymentQueue.default().restoreCompletedTransactions()
   }

    private func handlePurchase(_ id: String) {

        print("Purchased the item \(id)")
        let window = UIApplication.shared.windows
        window.last?.makeToast("Already you Subscribed this pack")

    }

}
