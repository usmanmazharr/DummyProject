
import UIKit

class LanguageViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var header_title: UILabel!

    var lanArray = ["English", "Italian"]
    var isSelectedIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tblView.register(UINib(nibName: "LanguageCell", bundle: nil), forCellReuseIdentifier: "LanguageCell")
        
        header_title.text = "Language".localized()

        
        if LanguageManager.shared.currentLanguage == "en"
        {
            isSelectedIndex = 0
        }
        else
        {
            isSelectedIndex = 1
        }
    }
    

    @IBAction func clickedBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lanArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //variable type is inferred
        let cell = tableView.dequeueReusableCell(withIdentifier: "LanguageCell") as! LanguageCell

        cell.lbl_title?.text = lanArray[indexPath.row]
        
        if isSelectedIndex == indexPath.row
        {
            cell.iv_language.image = UIImage(named: "tick")
        }
        else
        {
            cell.iv_language.image = nil
        }
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0
        {
            LanguageManager.shared.setLanguage("en") // Change the language to French
//            Bundle.main.path(forResource: "en", ofType: "lproj")
//            Bundle.setLanguage("en")
        }
        else
        {
            LanguageManager.shared.setLanguage("it") // Change the language to French
//            Bundle.main.path(forResource: "it", ofType: "lproj")
//            Bundle.setLanguage("it")

        }
                
//        self.navigationController?.popToRootViewController(animated: true)
        reloadRootViewController()
        
        isSelectedIndex = indexPath.row
        tblView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
}

func reloadRootViewController() {

    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
    let home = storyBoard.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
    
    let homeNavigation = UINavigationController(rootViewController: home)
    homeNavigation.navigationBar.isHidden = true
    appDelegate.window?.rootViewController = homeNavigation
    appDelegate.window?.makeKeyAndVisible()
    
//    let delegate = UIApplication.shared.delegate as! AppDelegate
//        let storyString = "Main"
//        let storyboard : UIStoryboard = UIStoryboard(name: storyString, bundle: nil)
//    let home: DashboardViewController = storyboard.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
//    let homeNavigation = UINavigationController(rootViewController: home)

//        delegate.window?.rootViewController = home
//    delegate.window?.makeKeyAndVisible()

//    let mainStoryboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//    let home: HomeViewController = mainStoryboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
//    let homeNavigation = UINavigationController(rootViewController: home)
//    homeNavigation.navigationBar.isHidden = true
//    self.window?.rootViewController = homeNavigation
//    self.window?.makeKeyAndVisible()
    }

//extension String {
//    func localized() -> String {
//        return NSLocalizedString(self, tableName: "Localizable", bundle: .main, value: self, comment: self)
//    }
//
//    func localizeWithFormat(arguments: CVarArg...) -> String{
//        return String(format: self.localized(), arguments: arguments)
//    }
//}

extension String {
        

    func localized() -> String{
        let LANGUAGE = LanguageManager.shared.currentLanguage
        
        let path = Bundle.main.path(forResource: LANGUAGE, ofType: "lproj")
        let bundle = Bundle(path: path!)
        
        return NSLocalizedString(self, tableName: nil, bundle: bundle!, value: "", comment: "")
    }
}
