 
import Foundation

class FVUserLoginData : NSObject, NSCoding{

    var date : String!
    var email : String!
    var userId : String!


    /**
     * Overiding init method
     */
    init(fromDictionary dictionary: NSDictionary)
    {
        super.init()
        parseJSONData(fromDictionary: dictionary)
    }

    /**
     * Overiding init method
     */
    override init(){
    }

    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    @objc func parseJSONData(fromDictionary dictionary: NSDictionary)
    {
        date = dictionary["date"] as? String == nil ? "" : dictionary["date"] as? String
        email = dictionary["email"] as? String == nil ? "" : dictionary["email"] as? String
        userId = dictionary["user_id"] as? String == nil ? "" : dictionary["user_id"] as? String
    }

    /**
     * Returns all the available property values in the form of NSDictionary object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> NSDictionary
    {
        let dictionary = NSMutableDictionary()
        if date != nil{
            dictionary["date"] = date
        }
        if email != nil{
            dictionary["email"] = email
        }
        if userId != nil{
            dictionary["user_id"] = userId
        }
        return dictionary
    }

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
    {
         date = aDecoder.decodeObject(forKey: "date") as? String
         email = aDecoder.decodeObject(forKey: "email") as? String
         userId = aDecoder.decodeObject(forKey: "user_id") as? String

    }

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    public func encode(with aCoder: NSCoder)
    {
        if date != nil{
            aCoder.encode(date, forKey: "date")
        }
        if email != nil{
            aCoder.encode(email, forKey: "email")
        }
        if userId != nil{
            aCoder.encode(userId, forKey: "user_id")
        }

    }

}
