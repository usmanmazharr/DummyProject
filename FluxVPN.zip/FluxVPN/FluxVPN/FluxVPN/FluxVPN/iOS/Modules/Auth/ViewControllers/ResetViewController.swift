 
import UIKit
import MaterialComponents

class ResetViewController: UIViewController {

    @IBOutlet weak var txtEmail: MDCOutlinedTextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtEmail.textColor = UIColor.white
//        txtEmail.keyboardAppearance = .

        txtEmail.label.text = "Email".localized()
        txtEmail.label.textColor  = UIColor(red: 180/255, green: 180/250, blue: 180/255, alpha: 1)

//        txtEmail.label.font = UIFont(name: "Poppins-medium", size: 13)

        txtEmail.placeholder = ""
      //  txtEmail.font = UIFont(name: "Poppins-medium", size: 13)
        
        txtEmail.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        txtEmail.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtEmail.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .editing)
        
        txtEmail.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtEmail.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .disabled)
        txtEmail.setOutlineColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        
        txtEmail.setFloatingLabelColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtEmail.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtEmail.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        
        txtEmail.containerRadius = 5
        txtEmail.trailingEdgePaddingOverride = 35
        txtEmail.keyboardType = .emailAddress
        txtEmail.verticalDensity = 52
        txtEmail.preferredContainerHeight = 52

        // Do any additional setup after loading the view.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    
    @IBAction func clickeReset(_ sender: Any) {
        
        self.view.hideAllToasts()
        let window = UIApplication.shared.windows
        window.last?.hideAllToasts()
        
        if txtEmail.text == ""
        {
            self.view.makeToast("Please enter email")
            let window = UIApplication.shared.windows
            window.last?.makeToast("Please enter email")
        }
        else
        {
            callResetAPI()
        }
    }
    
    @IBAction func clickedBck(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func callResetAPI()
    {
        APIClient.sharedInstance.showIndicator()

        let param = ["email": self.txtEmail.text ?? ""]
        
        print(param)
        
        APIClient.sharedInstance.MakeAPICallWithOutAuthHeaderGet(RESET_USER, parameters: param) {
            response, error, statusCode in
            
            print("STATUS CODE \(String(describing: statusCode))")
            print("RESPONSE \(String(describing: response))")
            
            if error == nil
            {
                APIClient.sharedInstance.hideIndicator()
                
                let dicUserAuth = response?.value(forKey: "UserAuth") as? NSDictionary

                let status = dicUserAuth?.value(forKey: "success") as? Int
                let message = dicUserAuth?.value(forKey: "message") as? String
                
                if statusCode == 200
                {
                    self.view.makeToast(message)
                    let window = UIApplication.shared.windows
                    window.last?.makeToast(message)
                    
                    self.navigationController?.popViewController(animated: true)
                }
                else
                {
                    self.view.makeToast(message)
                    let window = UIApplication.shared.windows
                    window.last?.makeToast(message)
                }
            }
            else
            {
                APIClient.sharedInstance.hideIndicator()
            }
        }
    }
    
}

