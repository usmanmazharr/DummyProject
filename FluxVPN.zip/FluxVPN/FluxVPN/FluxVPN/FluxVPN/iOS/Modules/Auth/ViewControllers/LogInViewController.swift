 
import UIKit
import Toast_Swift
import MaterialComponents
import Localize_Swift

class LogInViewController: BaseViewController {
    @IBOutlet weak var txtUsername: MDCOutlinedTextField!
    @IBOutlet weak var txtPassword: MDCOutlinedTextField!
    @IBOutlet weak var imgPass: UIImageView!

    var isShow = false

    override func viewDidLoad() {
        super.viewDidLoad()

//        txtUsername.text = "Riasat" // "Riasat ali"
//        txtPassword.text =  "Lapassword1@" //"Riasat123@#£"
        txtUsername.textColor = UIColor.white
        txtPassword.textColor = UIColor.white
        setUp()
        txtUsername.becomeFirstResponder()
        txtPassword.becomeFirstResponder()
        let loginData = AppUtilites().getCurrentUserData()
        print("MERA  loginData  \(loginData.userId)")
        // Do any additional setup after loading the view.
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    func setUp() {
        txtUsername.label.text = "Username".localized()
        txtUsername.label.textColor  = UIColor(red: 180.0/255.0, green: 180.0/250.0, blue: 180.0/255.0, alpha: 1)

        txtUsername.placeholder = ""

        txtUsername.setNormalLabelColor(UIColor(red: 88/255.0, green: 88/255.0, blue: 88/255.0, alpha: 1), for: .normal)
        txtUsername.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtUsername.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .editing)

        txtUsername.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtUsername.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .disabled)
        txtUsername.setOutlineColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)

        txtUsername.setFloatingLabelColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtUsername.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtUsername.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)

        txtUsername.containerRadius = 5
        txtUsername.trailingEdgePaddingOverride = 35
        txtUsername.keyboardType = .default
        txtUsername.verticalDensity = 52
        txtUsername.preferredContainerHeight = 52

        txtPassword.label.text = "Password".localized()
        txtPassword.label.textColor  = UIColor(red: 180/255, green: 180/250, blue: 180/255, alpha: 1)
        //        txtPassword.label.font = UIFont(name: "Poppins-medium", size: 13)

        txtPassword.placeholder = ""
        //  txtPassword.font = UIFont(name: "Poppins-medium", size: 13)

        txtPassword.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        txtPassword.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtPassword.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .editing)

        txtPassword.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtPassword.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .disabled)
        txtPassword.setOutlineColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)

        txtPassword.setFloatingLabelColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtPassword.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtPassword.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)

        txtPassword.containerRadius = 5
        txtPassword.trailingEdgePaddingOverride = 35
        txtPassword.keyboardType = .default
        txtPassword.isSecureTextEntry = true
        txtPassword.verticalDensity = 52
        txtPassword.preferredContainerHeight = 52

    }

    @IBAction func clickedShowPass(_ sender: Any) {

        if isShow == true {
            isShow = false
            txtPassword.isSecureTextEntry = true
            imgPass.image = UIImage(named: "ic_Show")
        } else {
            isShow = true
            txtPassword.isSecureTextEntry = false
            imgPass.image = UIImage(named: "ic_Hide")
        }

    }

    @IBAction func clickedLogin(_ sender: Any) {
        self.view.hideAllToasts()
        let window = UIApplication.shared.windows
        window.last?.hideAllToasts()

        if txtUsername.text == "" {
            self.view.makeToast("Please enter your username")
            let window = UIApplication.shared.windows
            window.last?.makeToast("Please enter your username")

        } else if txtPassword.text == "" {
            self.view.makeToast("Please enter your password")
            let window = UIApplication.shared.windows
            window.last?.makeToast("Please enter your password")

        } else {
            callLoginAPI()
        }

    }

    func callLoginAPI() {

        APIClient.sharedInstance.showIndicator()

        let param = ["username": self.txtUsername.text ?? "", "password": self.txtPassword.text ?? ""]

        print(param)

        APIClient.sharedInstance.MakeAPICallWithOutAuthHeaderGet(LOGIN_USER, parameters: param) {
            response, error, statusCode in

            print("STATUS CODE \(String(describing: statusCode))")
            print("RESPONSE \(String(describing: response))")

            if error == nil {
                APIClient.sharedInstance.hideIndicator()

                let dicUserAuth = response?.value(forKey: "UserAuth") as? NSDictionary

                let status = dicUserAuth?.value(forKey: "success") as? Int
                let message = dicUserAuth?.value(forKey: "message") as? String

                if statusCode == 200 {

                    self.view.makeToast(message)
                    let window = UIApplication.shared.windows
                    window.last?.makeToast(message)

                    if status == 1 {
                        UserDefaults.standard.set(true, forKey: "isUserLogin")
                        UserDefaults.standard.synchronize()

                        let dicData = dicUserAuth?.value(forKey: "data") as? NSDictionary
                        AppUtilites().saveCurrentUserData(dic: FVUserLoginData(fromDictionary: dicData!))

                        appDelegate.saveCurrentUserData(dic: FVUserLoginData(fromDictionary: dicData!))
                         appDelegate.dicCurrentUserData = FVUserLoginData(fromDictionary: dicData!)
                        print("MERA Login dicData   ",dicData)
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let home = storyBoard.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
                        
                        let homeNavigation = UINavigationController(rootViewController: home)
                        homeNavigation.navigationBar.isHidden = true
                        appDelegate.window?.rootViewController = homeNavigation
                        appDelegate.window?.makeKeyAndVisible()
                         
                    }
                } else {
                    self.view.makeToast(message)
                    let window = UIApplication.shared.windows
                    window.last?.makeToast(message)
                }
            } else {
                APIClient.sharedInstance.hideIndicator()
            }
        }

    }

}

class YourNavigationController: UINavigationController {
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
