 
import UIKit
import MaterialComponents

class RegisterViewController: UIViewController {
    
    @IBOutlet weak var txtEmail: MDCOutlinedTextField!
    @IBOutlet weak var txtUsername: MDCOutlinedTextField!
    @IBOutlet weak var txtPassword: MDCOutlinedTextField!
    @IBOutlet weak var imgPass: UIImageView!
    
    var isShow = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtUsername.textColor = UIColor.white
        txtPassword.textColor = UIColor.white
        txtEmail.textColor = UIColor.white

        txtEmail.label.text = "Email".localized()
        txtEmail.label.textColor  = UIColor(red: 180/255, green: 180/250, blue: 180/255, alpha: 1)
        
        //        txtEmail.label.font = UIFont(name: "Poppins-medium", size: 13)
        
        txtEmail.placeholder = ""
        //  txtEmail.font = UIFont(name: "Poppins-medium", size: 13)
        
        txtEmail.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        txtEmail.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtEmail.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .editing)
        
        txtEmail.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtEmail.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .disabled)
        txtEmail.setOutlineColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        
        txtEmail.setFloatingLabelColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtEmail.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtEmail.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        
        txtEmail.containerRadius = 5
        txtEmail.trailingEdgePaddingOverride = 35
        txtEmail.keyboardType = .emailAddress
        txtEmail.verticalDensity = 52
        txtEmail.preferredContainerHeight = 52
        
        
        txtUsername.label.text = "Username".localized()
        txtUsername.label.textColor = UIColor(red: 180/255, green: 180/250, blue: 180/255, alpha: 1)
        
        //        txtUsername.label.font = UIFont(name: "Poppins-medium", size: 13)
        
        txtUsername.placeholder = ""
        //  txtUsername.font = UIFont(name: "Poppins-medium", size: 13)
        
        txtUsername.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        txtUsername.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtUsername.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .editing)
        
        txtUsername.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtUsername.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .disabled)
        txtUsername.setOutlineColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        
        txtUsername.setFloatingLabelColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtUsername.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtUsername.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        
        txtUsername.containerRadius = 5
        txtUsername.trailingEdgePaddingOverride = 35
        txtUsername.keyboardType = .default
        txtUsername.verticalDensity = 52
        txtUsername.preferredContainerHeight = 52
        
        
        txtPassword.label.text = "Password".localized()
        txtPassword.label.textColor  = UIColor(red: 180/255, green: 180/250, blue: 180/255, alpha: 1)
        //        txtPassword.label.font = UIFont(name: "Poppins-medium", size: 13)
        
        txtPassword.placeholder = ""
        //  txtPassword.font = UIFont(name: "Poppins-medium", size: 13)
        
        txtPassword.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        txtPassword.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtPassword.setNormalLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .editing)
        
        txtPassword.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtPassword.setOutlineColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .disabled)
        txtPassword.setOutlineColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        
        txtPassword.setFloatingLabelColor(UIColor(red: 171/255, green: 201/255, blue: 255/255, alpha: 1), for: .editing)
        txtPassword.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .disabled)
        txtPassword.setFloatingLabelColor(UIColor(red: 88/255, green: 88/255, blue: 88/255, alpha: 1), for: .normal)
        
        txtPassword.containerRadius = 5
        txtPassword.trailingEdgePaddingOverride = 35
        txtPassword.keyboardType = .default
        txtPassword.isSecureTextEntry = true
        txtPassword.verticalDensity = 52
        txtPassword.preferredContainerHeight = 52
        // Do any additional setup after loading the view.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    
    @IBAction func clickedShowPass(_ sender: Any) {
        
        if isShow == true
        {
            isShow = false
            txtPassword.isSecureTextEntry = true
            imgPass.image = UIImage(named: "ic_Show")
        }
        else
        {
            isShow = true
            txtPassword.isSecureTextEntry = false
            imgPass.image = UIImage(named: "ic_Hide")
        }
        
    }
    
    @IBAction func clickedCreateAccount(_ sender: Any) {
        
        self.view.hideAllToasts()
        let window = UIApplication.shared.windows
        window.last?.hideAllToasts()
        
        if txtEmail.text == ""
        {
            self.view.makeToast("Please provide email")
            let window = UIApplication.shared.windows
            window.last?.makeToast("Please provide email")
        }
        else if !AppUtilites.isValidEmail(testStr: txtEmail.text ?? "")
        {
            self.view.makeToast("Email is invalid")
            let window = UIApplication.shared.windows
            window.last?.makeToast("Email is invalid")

        }
        else if txtUsername.text == ""
        {
            self.view.makeToast("Please provide a username")
            let window = UIApplication.shared.windows
            window.last?.makeToast("Please provide a username")

        }
        else if txtPassword.text == ""
        {
            self.view.makeToast("Please provide a password")
            let window = UIApplication.shared.windows
            window.last?.makeToast("Please provide a password")

        }
        else if (txtPassword.text?.count ?? 0) < 6
        {
            self.view.makeToast("Password length should be greater than 5")
            let window = UIApplication.shared.windows
            window.last?.makeToast("Password length should be greater than 5")
        }
        else
        {
            callRegisiterAPI()
        }
        
    }
    
    @IBAction func clickedSignIn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func callRegisiterAPI()
    {
        APIClient.sharedInstance.showIndicator()

        let param = ["username": self.txtUsername.text ?? "", "password": self.txtPassword.text ?? "","email": self.txtEmail.text ?? "", "register": "active"]
        
        print(param)
        
        APIClient.sharedInstance.MakeAPICallWithOutAuthHeaderGet(LOGIN_USER, parameters: param) {
            response, error, statusCode in
            
            print("STATUS CODE \(String(describing: statusCode))")
            print("RESPONSE \(String(describing: response))")
            
            if error == nil
            {
                APIClient.sharedInstance.hideIndicator()
                
                let dicUserAuth = response?.value(forKey: "UserAuth") as? NSDictionary

                let status = dicUserAuth?.value(forKey: "success") as? Int
                let message = dicUserAuth?.value(forKey: "message") as? String
                
                if statusCode == 200
                {
                    
                    if status == 1
                    {
                        
                        self.view.makeToast(message)
                        let window = UIApplication.shared.windows
                        window.last?.makeToast(message)

                        self.navigationController?.popViewController(animated: true)
                    }
                    else
                    {
                        AppUtilites.showAlert(title: "Message", message: message ?? "", cancelButtonTitle: "Ok")
                    }
                }
                else
                {
                    self.view.makeToast(message)
                    let window = UIApplication.shared.windows
                    window.last?.makeToast(message)
                }
            }
            else
            {
                APIClient.sharedInstance.hideIndicator()
            }
        }
    }
    
    
}
