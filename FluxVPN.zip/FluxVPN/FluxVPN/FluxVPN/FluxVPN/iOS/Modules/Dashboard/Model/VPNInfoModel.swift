 
import Foundation

struct VPNInfoModel: Decodable {
   
    let Serverinfo: ServerInfo?
    let Clientinfo: ClientInfo?
    let message: String?
    let success: Bool?
    let expired: Bool?
     
}
 
struct ServerInfo: Decodable {
    let nameserver: String?
    let endpoint: String
    let wg: String
    let allowedips: String
    let public_key: String
    let status: String
    let country: String
    let country_flag: String
    
    func getAddressAndPort () -> (address: String, port: String) {
        let arr = self.endpoint.split(separator: ":")
        let adr: String = String(arr[0])
        let p: String = String(arr[1])
        return (adr,p)
    }

}

struct ClientInfo: Decodable {
    let private_key: String
    let public_key: String
    let Address: String
    let dns: String
    let online: String
}


extension Decodable {
  init(from: Any) throws {
    let data = try JSONSerialization.data(withJSONObject: from, options: .prettyPrinted)
    let decoder = JSONDecoder()
    self = try decoder.decode(Self.self, from: data)
  }
}
