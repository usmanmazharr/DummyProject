 
import UIKit
import SDWebImage
import Alamofire
import Network
import PlainPing

class VPNInfoCell: UITableViewCell {

    @IBOutlet weak var imgFlag: UIImageView!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblSunName: UILabel!
    @IBOutlet weak var imgGraph: UIImageView!
    
    @IBOutlet weak var containerView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func setupData(data: FVHomePageServerInfo, currentConneced: String? ) {
        if let cur = currentConneced {
            if cur == data.nameserver {
                
                self.containerView.backgroundColor = #colorLiteral(red: 0, green: 0.3568627451, blue: 0.7529411765, alpha: 0.7961575255)
            } else {
                self.containerView.backgroundColor = #colorLiteral(red: 0.1215686275, green: 0.1215686275, blue: 0.1450980392, alpha: 1)
            }
        } else {
            self.containerView.backgroundColor = #colorLiteral(red: 0.1215686275, green: 0.1215686275, blue: 0.1450980392, alpha: 1)
        }
        
        if data.status == 0 {
            imgGraph.image = UIImage(named: "graph-bar")?.withTintColor(UIColor(named: "#BA1A1A") ?? .red, renderingMode: .alwaysOriginal)
        } else {
            imgGraph.image = UIImage(named: "graph-bar")?.withTintColor(UIColor(named: "#BA1A1A") ?? .green, renderingMode: .alwaysOriginal)
        }
        
        self.lblName.text = data.nameserver ?? ""
        self.lblSunName.isHidden = true
        var media_link_url = data.countryFlag ?? ""
        media_link_url = (media_link_url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed))!
        self.imgFlag.sd_setImage(with: URL.init(string: media_link_url), placeholderImage: nil, options: [], completed: nil)

        let address = data.endpoint.components(separatedBy: ":")
        print(address)
//        PlainPing.ping(address[0], withTimeout: 1.0, completionBlock: { (timeElapsed:Double?, error:Error?) in
//            if let latency = timeElapsed {
//                                let start = CFAbsoluteTimeGetCurrent()
//                                let end = CFAbsoluteTimeGetCurrent()
////                    let /*latencysss*/ = (end - start) * 100
//                let latencysss = String(latency)
//
//                let sec = latencysss.components(separatedBy: ".")
//                let prefix = sec[0]
//                print(prefix)
//                self.lblSunName.text = "\(prefix) MS"
//            }
//
//            if let error = error {
//                print("error: \(error.localizedDescription)")
//            }
//        })
    }
    
}
