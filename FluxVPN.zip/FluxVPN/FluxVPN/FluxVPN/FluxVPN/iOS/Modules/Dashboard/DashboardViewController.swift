 
import UIKit
import Alamofire
import SDWebImage
import Network
import TunnelKitManager
import TunnelKitWireGuard

private let appGroup = "group.gecolux.kulosia"
private let tunnelIdentifier = "com.gecolux.vpn.Tunnel"

class DashboardViewController: BaseViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var wifiImage: UIImageView!
    @IBOutlet weak var lbl_expiryDate: UILabel!
    @IBOutlet weak var lbl_noData: UILabel!
    
    @IBAction func btnWifiAction(_ sender: Any) {
        if vpnStatus == .connected {
            self.showAlert(title: "Disconnect_VPN".localized(), desc: "Disconnect_VPN_MSG".localized(), isAlreadyConnected: false) {
                Task {
                    await self.vpn.disconnect()
                    self.logOutVPN {
                        self.currentConnected = nil
                        AppUtilites.Singleton.sharedInstance.currentConnectedTEMP = nil

                        UserDefaults.standard.setValue(nil, forKey: "currentConnectedName")
                        UserDefaults.standard.setValue(nil, forKey: "currentConnectedID")

                        self.wifiImage.image = UIImage(named: "wifi")?.withTintColor(UIColor(named: "#BA1A1A") ?? .red, renderingMode: .alwaysOriginal)
                        self.tableView.reloadData()
                    }
                   
                }
            }
        } else {
            self.showAlert(title: "VPN_Connection_Error".localized(), desc: "VPN_Connection_MSG".localized(), isAlreadyConnected: true) {

                       }
        }
        
       
        
    }
    
    @IBAction func btnGoToPremium(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let premimum = storyBoard.instantiateViewController(withIdentifier: "PremiumViewController") as! PremiumViewController
        self.navigationController?.pushViewController(premimum, animated: true);
    }
    
    @IBAction func btnGoToSetting(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let settings = storyBoard.instantiateViewController(withIdentifier: "SettingViewController") as! SettingViewController
        settings.vpnInfo = vpnInfo
        settings.vpnStatus = vpnStatus
        self.navigationController?.pushViewController(settings, animated: true);
    }
    
    var arrHome: [FVHomePageServerInfo] = [FVHomePageServerInfo]()
    var currentConnected: FVHomePageServerInfo!
//    var currentConnectedTEMP: FVHomePageServerInfo!
    private let vpn = NetworkExtensionVPN()
    private var vpnStatus: VPNStatus = .disconnected
    
    private var vpnInfo : VPNInfoModel?
    
    var isUserExpired: Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(UINib(nibName: "VPNInfoCell", bundle: nil), forCellReuseIdentifier: "VPNInfoCell")
        
        let loginData = AppUtilites().getCurrentUserData()

        lbl_expiryDate.text = "\("Expire_date".localized()) \(loginData.date ?? "")"

        if let savedVpnInfo = UserDefaults.standard.value(forKey: "vpnInfo") as? Data
        {
            let decoder = JSONDecoder()
            
            do
            {
                let vpnInfo = try decoder.decode(VPNInfoModel.self, from: savedVpnInfo)
                self.vpnInfo = vpnInfo
                
                self.connectVPN()
                self.tableView.reloadData()
                
            }catch
            {
                print("Error:",error.localizedDescription)
            }
        }
        
        getVPNInfoList()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(VPNStatusDidChange(notification:)),
            name: VPNNotification.didChangeStatus,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(VPNDidFail(notification:)),
            name: VPNNotification.didFail,
            object: nil
        )

        Task {
            await vpn.prepare()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

    }
    
    @objc private func VPNStatusDidChange(notification: Notification) {
        vpnStatus = notification.vpnStatus
        
        switch notification.vpnStatus {
        case .connected:
//            self.currentConnected = self.currentConnectedTEMP
            //self.currentConnectedTEMP = nil
            wifiImage.image = UIImage(named: "wifi")?.withTintColor(UIColor(named: "#17CE92") ?? .green, renderingMode: .alwaysOriginal)
            tableView.reloadData()
        case .disconnected:
            self.currentConnected = nil
            wifiImage.image = UIImage(named: "wifi")?.withTintColor(UIColor(named: "#BA1A1A") ?? .red, renderingMode: .alwaysOriginal)
            tableView.reloadData()
        default:
            wifiImage.image = UIImage(named: "wifi")?.withTintColor(UIColor(named: "#BA1A1A") ?? .red, renderingMode: .alwaysOriginal)

        }
        print("MERA VPNStatusDidChange  \(notification.vpnStatus) --   \(self.currentConnected?.id)")
        
    }

    @objc private func VPNDidFail(notification: Notification) {
        print("VPNStatusDidFail: \(notification.vpnError.localizedDescription)")
        wifiImage.image?.withTintColor(UIColor(named: "#17CE92") ?? .red)
        wifiImage.image = UIImage(named: "wifi")?.withTintColor(UIColor(named: "#BA1A1A") ?? .red, renderingMode: .alwaysOriginal)
        currentConnected = nil
        AppUtilites.Singleton.sharedInstance.currentConnectedTEMP = nil
        UserDefaults.standard.setValue(nil, forKey: "currentConnectedName")
        UserDefaults.standard.setValue(nil, forKey: "currentConnectedID")
    }
    
    func getVPNInfoList()
    {
        APIClient.sharedInstance.showIndicator()
        
        let param = ["":""]
        
        let headers: HTTPHeaders = ["Token":"mIjuu3bYa3kK1STn5uf8ylbLi0veLTb5","Token2": AppUtilites().getCurrentUserData().userId ?? ""]
        
        print(param)
        
        APIClient.sharedInstance.MakeAPICallWithAuthHeaderManualGet(HOME_PAGE,headers: headers, parameters: param) {
            response, error, statusCode in
            
            print("STATUS CODE \(String(describing: statusCode))")
            print("RESPONSE \(String(describing: response))")
            
            if error == nil
            {
                APIClient.sharedInstance.hideIndicator()
                
                let expired = response?.value(forKey: "expired") as? Int
                self.isUserExpired = expired == 0 ? false : true
                self.arrHome.removeAll()
                
                if statusCode == 200
                {
                    if expired == 0
                    {
                        self.lbl_noData.isHidden = true

                        let arrServerInfo = response?.value(forKey: "server_info") as? NSArray
                        
                        if (arrServerInfo?.count ?? 0) > 0
                        {
                            for obj in arrServerInfo!
                            {
                                let ducDaya = FVHomePageServerInfo(fromDictionary: obj as! NSDictionary)
                                self.arrHome.append(ducDaya)
                            }
                        }
                        
                    } else {
                        self.lbl_noData.isHidden = false
                        self.lbl_noData.text = "No_server".localized()
                    }

                    self.tableView.reloadData()

                }
                else
                {
                }
                
            }
            else
            {
                APIClient.sharedInstance.hideIndicator()
                self.arrHome.removeAll()
                self.tableView.reloadData()
            }
        }
    }
    
    func parseData(dict: NSDictionary) {
        
        let json: [String: Any] = dict as! [String : Any]
        let data = try! JSONSerialization.data(withJSONObject: json, options: .prettyPrinted)
        let decoder = JSONDecoder()
        do {
            let vpnInfo = try decoder.decode(VPNInfoModel.self, from: data)
            self.vpnInfo = vpnInfo
            UserDefaults.standard.set(data, forKey: "vpnInfo")

            // expired
            if isUserExpired {
                self.showAlert(title: "VPN_expired".localized(), desc: "VPN_expired_MSG".localized(), isAlreadyConnected: true)
                return
            } else {
                self.connectVPN()
                self.tableView.reloadData()

            }
            print(" ======= vpnInfo ==>  ", vpnInfo)
        } catch {
            print(error.localizedDescription)
        }
        
    }
    
    func connectVPN() {
        if let vpnInfo = self.vpnInfo {
            if vpnInfo.Clientinfo == nil || vpnInfo.Serverinfo == nil {
                print("  ==================== NO VPN INFO =======================  ")
                self.showAlert(title: "double_connection".localized(), desc: "double_connection_MSG".localized(), isAlreadyConnected: true)
                Task {
                    await self.vpn.disconnect()
                    self.logOutVPN {
                        self.vpnStatus = .disconnected
                        self.currentConnected = nil
                        AppUtilites.Singleton.sharedInstance.currentConnectedTEMP = nil
                        self.wifiImage.image = UIImage(named: "wifi")?.withTintColor(UIColor(named: "#BA1A1A") ?? .red, renderingMode: .alwaysOriginal)
                        self.wifiImage.image?.withTintColor(UIColor(named: "#17CE92") ?? .red)
                        self.wifiImage.image = UIImage(named: "wifi")?.withTintColor(UIColor(named: "#BA1A1A") ?? .red, renderingMode: .alwaysOriginal)
                        AppUtilites.Singleton.sharedInstance.currentConnectedTEMP = nil
                        UserDefaults.standard.setValue(nil, forKey: "currentConnectedName")
                        UserDefaults.standard.setValue(nil, forKey: "currentConnectedID")
                        self.tableView.reloadData()

                    }
                   
                }

                
            } else {
                let clientPrivateKey = vpnInfo.Clientinfo!.private_key
                let clientAddress = vpnInfo.Clientinfo!.Address
                let serverPublicKey = vpnInfo.Serverinfo!.public_key
                let serverAddress = vpnInfo.Serverinfo!.getAddressAndPort().address
                let serverPort = vpnInfo.Serverinfo!.getAddressAndPort().port
                
                // expired
                if isUserExpired {
                    self.showAlert(title: "VPN_expired".localized(), desc: "VPN_expired_MSG".localized(), isAlreadyConnected: true)
                    return
                } else {
                    guard let cfg = WireGuard.DemoConfiguration.make(params: .init(
                        title: "FluxVPN",
                        appGroup: appGroup,
                        clientPrivateKey: clientPrivateKey,
                        clientAddress: clientAddress,
                        serverPublicKey: serverPublicKey,
                        serverAddress: serverAddress,
                        serverPort: serverPort
                    )) else {
                        print("Configuration incomplete")
                        return
                    }
                    
                    print("MERA cfg \(cfg.configuration)")

                    Task {
                        try await vpn.reconnect(
                            tunnelIdentifier,
                            configuration: cfg,
                            extra: nil,
                            after: .seconds(1)
                        )
                    }
                }
                 
            }
        }
        
    }
    
    func getServerInfo(serverId: String) {
        APIClient.sharedInstance.showIndicator()
        let param = ["":""]
        let headers: HTTPHeaders = [
            "Token":"mIjuu3bYa3kK1STn5uf8ylbLi0veLTb5",
            "CLIENT": AppUtilites().getCurrentUserData().userId ?? "",
            "ID": serverId
        ]
        APIClient.sharedInstance.MakeAPICallWithAuthHeaderManualGet(GET_SEVER_INFO,headers: headers, parameters: param) {
            response, error, statusCode in
            if error == nil
            {
                APIClient.sharedInstance.hideIndicator()
                //let serverInfo = response?.value(forKey: "Serverinfo") as? NSDictionary
                if statusCode == 200
                {
                    print("MERA getServerInfo  =>   \(String(describing: response))")
                    self.parseData(dict: response!)

                }
            }
            else
            {
                print("getServerInfo Error \(String(describing: response))")
                APIClient.sharedInstance.hideIndicator()
                self.arrHome.removeAll()
                self.tableView.reloadData()
            }
        }

    }
    
    func logOutVPN( completion: @escaping (() -> Void)) {
        let param = ["":""]
        let clientAddress: String = self.vpnInfo?.Clientinfo?.Address ?? ""
        let headers: HTTPHeaders = [
            "Token":"mIjuu3bYa3kK1STn5uf8ylbLi0veLTb5",
            "ID": AppUtilites().getCurrentUserData().userId ?? "",
            "IP": clientAddress
           
        ]
        APIClient.sharedInstance.showIndicator()
        APIClient.sharedInstance.MakeAPICallWithAuthHeaderManualGet("api_client_logout.php",headers: headers, parameters: param) {
            response, error, statusCode in
            APIClient.sharedInstance.hideIndicator()
            if error == nil
            {
                if statusCode == 200
                {
                    UserDefaults.standard.set(nil, forKey: "vpnInfo")
                    completion()
                    self.tableView.reloadData()
                }
            }
            else
            {
                UserDefaults.standard.setValue(nil, forKey: "currentConnectedName")
                UserDefaults.standard.setValue(nil, forKey: "currentConnectedID")
                UserDefaults.standard.set(nil, forKey: "vpnInfo")

                APIClient.sharedInstance.hideIndicator()
                print("getServerInfo Error \(String(describing: response))")
           
            }
        }
    }
    
    func showAlert(title: String, desc: String, isAlreadyConnected: Bool, completion: (() -> Void)? = nil ) {
        let dialogMessage = UIAlertController(title:title, message: desc, preferredStyle: .alert)
        //var dialogMessage = UIAlertController(title: "VPN Expired", message: "Your VPN subscription has expired. Please renew to continue using the", preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
            print("--OK--")
            completion?()
         })
        //Add OK button to a dialog message
        dialogMessage.addAction(ok)
        
        if isAlreadyConnected == true {
            
        } else {
            dialogMessage.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: { (action) -> Void in
                print("--Cancel--")
                 
             }))
        }
        // Present Alert to
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
    func changeServerShowAlert(title: String, desc: String, index: IndexPath, completion: (() -> Void)? = nil ) {
        let dialogMessage = UIAlertController(title:title, message: desc, preferredStyle: .alert)
        //var dialogMessage = UIAlertController(title: "VPN Expired", message: "Your VPN subscription has expired. Please renew to continue using the", preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
            print("--OK--")
            completion?()
         })
        
        //Add OK button to a dialog message
        dialogMessage.addAction(ok)

        dialogMessage.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: { (action) -> Void in
            print("--Cancel--")
            let cell = self.tableView.cellForRow(at: index) as! VPNInfoCell
            cell.containerView.backgroundColor = #colorLiteral(red: 0.1215686275, green: 0.1215686275, blue: 0.1450980392, alpha: 0.7961575255)
         }))
        // Present Alert to
        self.present(dialogMessage, animated: true, completion: nil)
    }
}


extension DashboardViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrHome.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "VPNInfoCell") as! VPNInfoCell? else {
            fatalError()
        }
         
        let dicData = arrHome[indexPath.row]
                
        if let currentNameServer = UserDefaults.standard.value(forKey: "currentConnectedName") as? String
        {
            cell.setupData(data: dicData, currentConneced: currentNameServer)
        }
        else
        {
            cell.setupData(data: dicData, currentConneced: "")
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 95
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print("MERA isUserExpired: \(self.isUserExpired)")
        let serverId: String = "\(self.arrHome[indexPath.row].id ?? 0)"
        let curDisplayVPN = self.arrHome[indexPath.row]
          
        // expired
        if isUserExpired {
            self.showAlert(title: "VPN_expired".localized(), desc: "VPN_expired_MSG".localized(), isAlreadyConnected: true)
            return
        }
        
        // Status = 0
        if curDisplayVPN.status == 0 {
            self.showAlert(title: "Server_Maintenance".localized(), desc: "Server_Maintenance_MSG".localized(), isAlreadyConnected: true)
            return
        }
        
        // Already Connected
        if let cur = UserDefaults.standard.value(forKey: "currentConnectedID") as? Int {
            if cur == curDisplayVPN.id  {
                self.showAlert(title: "Connect_ALREADY".localized(), desc: "Connect_ALREADY_MSG".localized(), isAlreadyConnected: true)
                return
            } else {
                let cell = tableView.cellForRow(at: indexPath) as! VPNInfoCell
                cell.containerView.backgroundColor =  #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.07990539969)
                self.changeServerShowAlert(title: "Change_Server".localized(), desc: "Change_Server_MSG".localized(), index: indexPath) {
                    Task {
                        await self.vpn.disconnect()
                        self.logOutVPN {
                            self.currentConnected = nil
                            AppUtilites.Singleton.sharedInstance.currentConnectedTEMP = nil
                            self.wifiImage.image = UIImage(named: "wifi")?.withTintColor(UIColor(named: "#BA1A1A") ?? .red, renderingMode: .alwaysOriginal)
                            self.tableView.reloadData()
                            self.getServerInfo(serverId: serverId)
                            AppUtilites.Singleton.sharedInstance.currentConnectedTEMP = curDisplayVPN
                           UserDefaults.standard.setValue(curDisplayVPN.nameserver, forKey: "currentConnectedName")
                           UserDefaults.standard.setValue(curDisplayVPN.id, forKey: "currentConnectedID")
                            self.tableView.reloadData()

                        }
                       
                    }
                }
                return
            }
        } else {
            let cell = tableView.cellForRow(at: indexPath) as! VPNInfoCell
            cell.containerView.backgroundColor =  #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.07990539969)
            
            self.changeServerShowAlert(title: "Connect_VPN".localized(), desc: "Connect_MSG".localized(), index: indexPath) {
                self.getServerInfo(serverId: serverId)
                AppUtilites.Singleton.sharedInstance.currentConnectedTEMP = curDisplayVPN

                UserDefaults.standard.setValue(curDisplayVPN.nameserver, forKey: "currentConnectedName")
                UserDefaults.standard.setValue(curDisplayVPN.id, forKey: "currentConnectedID")

            }
        }
//        getServerInfo(serverId: serverId)
//        currentConnectedTEMP = curDisplayVPN
//        print("MERA DidSlect  \(currentConnectedTEMP?.id)")
    }
    
    func getResponse(serverId:String,curDisplayVPN:FVHomePageServerInfo)
    {
        APIClient.sharedInstance.showIndicator()

        DispatchQueue.main.async {
            // Put your code which should be executed with a delay here
            print("Task Completed 123 ......")

        }
    }
}
