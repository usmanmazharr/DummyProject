
import Foundation
import TunnelKitCore
import TunnelKitWireGuard

;extension WireGuard {
    struct Parameters {
        let title: String

        let appGroup: String

        let clientPrivateKey: String

        let clientAddress: String

        let serverPublicKey: String

        let serverAddress: String

        let serverPort: String
    }

    struct DemoConfiguration {
        static func make(params: Parameters) -> WireGuard.ProviderConfiguration? {
            var builder: WireGuard.ConfigurationBuilder
            do {
                builder = try WireGuard.ConfigurationBuilder(params.clientPrivateKey)
            } catch {
                print(">>> \(error)")
                return nil
            }
            builder.addresses = [params.clientAddress]
            builder.dnsServers = ["8.8.8.8"]
            do {
                try builder.addPeer(params.serverPublicKey, endpoint: "\(params.serverAddress):\(params.serverPort)")
            } catch {
                print(">>> \(error)")
                return nil
            }
            builder.addDefaultGatewayIPv4(toPeer: 0)
            let cfg = builder.build()

            return WireGuard.ProviderConfiguration(params.title, appGroup: params.appGroup, configuration: cfg)
        }
    }
}
