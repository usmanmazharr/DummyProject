

import Foundation

class LanguageManager {
    static let shared = LanguageManager()

    var currentLanguage = "en" // Default language code

    func setLanguage(_ languageCode: String) {
            UserDefaults.standard.set(languageCode, forKey: "AppleLanguages")
            UserDefaults.standard.synchronize()
            Bundle.setLanguage(languageCode)
            currentLanguage = languageCode
    }
}

extension Bundle {
    static func setLanguage(_ languageCode: String) {
        var onceToken:Int = 0
        
        if(onceToken == 0)
        {
            object_setClass(Bundle.main, PrivateBundle.self)
        }
        onceToken = 1
        
        objc_setAssociatedObject(Bundle.main, &associatedLanguageBundle, (languageCode != "") ? Bundle(path: Bundle.main.path(forResource: languageCode, ofType: "lproj") ?? "") : "", .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
    }
}

private var associatedLanguageBundle: Character = "0"


class PrivateBundle: Bundle {
    override func localizedString(forKey key: String, value: String?, table tableName: String?) -> String {
        
        let bundle:Bundle? = objc_getAssociatedObject(self, &associatedLanguageBundle) as? Bundle

        return (bundle != nil) ? (bundle!.localizedString(forKey: key, value: value, table: tableName)) : (bundle!.localizedString(forKey: key, value: value, table: tableName))
    }
}


