
#import <Foundation/Foundation.h>

#import "RoutingTableEntry.h"

NS_ASSUME_NONNULL_BEGIN

@interface RoutingTable : NSObject

- (NSArray<RoutingTableEntry *> *)ipv4;
- (NSArray<RoutingTableEntry *> *)ipv6;
- (nullable RoutingTableEntry *)defaultGateway4;
- (nullable RoutingTableEntry *)defaultGateway6;
- (nullable RoutingTableEntry *)broadestRoute4MatchingDestination:(NSString *)destination;
- (nullable RoutingTableEntry *)broadestRoute6MatchingDestination:(NSString *)destination;

@end

NS_ASSUME_NONNULL_END
