

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RoutingTableEntry : NSObject

- (instancetype)initWithIPv4Network:(NSString *)network gateway:(nullable NSString *)gateway networkInterface:(NSString *)networkInterface;
- (instancetype)initWithIPv6Network:(NSString *)network gateway:(nullable NSString *)gateway networkInterface:(NSString *)networkInterface;

- (BOOL)isIPv6;
- (NSString *)network;
- (NSInteger)prefix;
- (nullable NSString *)networkMask; // nil if IPv6
- (nullable NSString *)gateway;
- (NSString *)networkInterface;

- (BOOL)isDefault;
- (BOOL)matchesDestination:(NSString *)destination;
- (nullable NSArray<RoutingTableEntry *> *)partitioned;

@end

NS_ASSUME_NONNULL_END
