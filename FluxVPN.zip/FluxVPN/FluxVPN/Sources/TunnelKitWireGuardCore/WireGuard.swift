

import Foundation

public class WireGuard {
}
