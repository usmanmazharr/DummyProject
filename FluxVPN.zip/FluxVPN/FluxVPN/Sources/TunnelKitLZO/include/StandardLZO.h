#import <Foundation/Foundation.h>

extern NSString *const TunnelKitLZOErrorDomain;
