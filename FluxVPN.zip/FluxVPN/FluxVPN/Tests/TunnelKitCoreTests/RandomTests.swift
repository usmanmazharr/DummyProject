

import XCTest
@testable import TunnelKitCore

class RandomTests: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testRandom1() {
        print(try! SecureRandom.uint32())
        print(try! SecureRandom.uint32())
        print(try! SecureRandom.uint32())
        print(try! SecureRandom.uint32())
        print(try! SecureRandom.uint32())
    }

    func testRandom2() {
        print("random UInt32: \(try! SecureRandom.uint32())")
        print("random bytes: \(try! SecureRandom.data(length: 12).toHex())")
    }
}
